import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-contest-report',
  templateUrl: './contest-report.component.html',
  styleUrls: ['./contest-report.component.css']
})
export class ContestReportComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
