import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-course-report',
  templateUrl: './course-report.component.html',
  styleUrls: ['./course-report.component.css']
})
export class CourseReportComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
