import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-edit-exam',
  templateUrl: './edit-exam.component.html',
  styleUrls: ['./edit-exam.component.css']
})
export class EditExamComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
