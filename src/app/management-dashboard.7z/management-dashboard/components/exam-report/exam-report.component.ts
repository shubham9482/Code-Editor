import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-exam-report',
  templateUrl: './exam-report.component.html',
  styleUrls: ['./exam-report.component.css']
})
export class ExamReportComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
