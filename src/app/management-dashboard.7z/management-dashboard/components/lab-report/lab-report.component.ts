import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-lab-report',
  templateUrl: './lab-report.component.html',
  styleUrls: ['./lab-report.component.css']
})
export class LabReportComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
