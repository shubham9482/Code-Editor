import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-practice-report',
  templateUrl: './practice-report.component.html',
  styleUrls: ['./practice-report.component.css']
})
export class PracticeReportComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
