import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-manage-status',
  templateUrl: './manage-status.component.html',
  styleUrls: ['./manage-status.component.css', '../admin-dashboard/admin-dashboard.component.css']
})
export class ManageStatusComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
